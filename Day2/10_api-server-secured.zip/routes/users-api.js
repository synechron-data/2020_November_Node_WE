var express = require('express');
var router = express.Router();
var cors = require('cors');

const users_api_ctrl = require('../controllers/users-api-controller');
const acc_ctrl = require('../controllers/account-controller');

router.use(cors());

router.use(acc_ctrl.validateToken);

router.get('/', users_api_ctrl.getUsers);

module.exports = router;
