// const chokidar = require('chokidar');
// // console.log(chokidar);

// const watcher = chokidar.watch('./my-folder');

// watcher.on('add', (path) => { console.log(`File, ${path}, has been created....`); });
// watcher.on('change', (path) => { console.log(`File, ${path}, has been modified....`); });
// watcher.on('unlink', (path) => { console.log(`File, ${path}, has been deleted....`); });

// console.log("Chokidar is watching.....");

// ----------------------------------------------------

const _ = require('lodash');

// var random = _.random(1, 20);
// console.log(random);

// var employees = [{ id: 1, name: "Manish" },
// { id: 2, name: "Abhijeet" },
// { id: 3, name: "Ram" },
// { id: 4, name: "Abhishek" },
// { id: 5, name: "Ramakant" }];

// // console.log(employees[employees.length - 1]);
// console.log(_.last(employees));

var e1 = { id: 1, name: "Manish", address: { city: "Pune" } };

// Reference Copy
// var e2 = e1;

// Shallow Copy
// var e2 = Object.assign({}, e1);

// Deep Copy
// var e2 = JSON.parse(JSON.stringify(e1));

// Using lodash
// var e2 = _.clone(e1);    // Shallow Copy    
var e2 = _.cloneDeep(e1);   // Deep Copy

e2.name = "Abhijeet";
e2.address.city = "Mumbai";

console.log("e1", e1);
console.log("e2", e2);
