console.log("This is the lib module loaded");
// console.log(module);

// var fname = "Manish";
// module.exports = fname;

// var lname = "Sharma";
// module.exports = lname;

// ------------------------------
// var fname = "Manish";
// var lname = "Sharma";

// module.exports = { firstname: fname, lastname: lname };

// ------------------------------
// var fname = "Manish";
// var lname = "Sharma";

// module.exports.firstname = fname;
// module.exports.lastname = lname;

// module.exports.log = function(){
//     return 'Hello from Lib.js module';
// }

// module.exports.Employee = (function () {
//     function Employee(name) {
//         this._name = name;
//     }

//     Employee.prototype.getName = function () {
//         return this._name;
//     }

//     Employee.prototype.setName = function (value) {
//         this._name = value;
//     }

//     return Employee;
// })();

// ------------------------------
var fname = "Manish";
var lname = "Sharma";

exports.firstname = fname;
exports.lastname = lname;

exports.log = function(){
    return 'Hello from Lib.js module';
}

// exports.Employee = (function () {
//     function Employee(name) {
//         this._name = name;
//     }

//     Employee.prototype.getName = function () {
//         return this._name;
//     }

//     Employee.prototype.setName = function (value) {
//         this._name = value;
//     }

//     return Employee;
// })();

class Employee {
    constructor(name) {
        this._name = name;
    }

    getName() {
        return this._name;
    }

    setName(value) {
        this._name = value;
    }
}

exports.Employee = Employee;