// const fs = require('fs');

// let fData = "";

// var readStream = fs.createReadStream('./file1.txt');

// readStream.on('open', () => {
//     console.log("File Opened....");
// });

// readStream.on('error', (err) => {
//     console.log(err);
// });

// // Chunk Size - 64 * 1024

// readStream.on('data', (chunk) => {
//     fData += chunk;
// });

// readStream.on('end', () => {
//     console.log("File End....");
//     console.log(fData);
// });

// ---------------------------------------------------- File Copy
const fs = require('fs');

var readStream = fs.createReadStream('./file1.txt');
var writeStream = fs.createWriteStream('./file2.txt');

readStream.on('data', (chunk) => {
    writeStream.write(chunk);
});

readStream.on('end', () => {
    console.log("File Copied....");
    readStream.close();
    writeStream.close();
});

// fs.readFile('./file1.txt', 'utf-8', (err, data) => {
//     if (err)
//         console.log(err);
//     else {
//         fs.writeFile('./file2-copy.txt', data, 'utf-8', (err) => {
//             if (err)
//                 console.log(err);
//             else
//                 console.log("File Copy Completed....");
//         });
//     }
// });