class Email {
    send(message) {
        console.log("Email Sent - ", message);
    }
}

module.exports = Email;